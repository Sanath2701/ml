let currentDay = 'DAY-1';
let scheduleData = {
  'DAY-1': [],
  'DAY-2': []
};
let editingIndex = -1;

async function switchDay(day) {
  currentDay = day;
  document.getElementById("schedule-title").innerText = currentDay;
  document.getElementById("btn-day-1").classList.remove("active");
  document.getElementById("btn-day-2").classList.remove("active");
  document.getElementById(`btn-${day.toLowerCase()}`).classList.add("active");

  // Fetch data from backend
  try {
    const res = await fetch(`http://localhost:5000/api/schedule/${currentDay}`);
    const data = await res.json();
    scheduleData[currentDay] = data;
  } catch (err) {
    console.error("Error loading schedule:", err);
    scheduleData[currentDay] = [];
  }

  renderTable();
  clearInputs();
  autoFillFromLast();
}

document.getElementById("addButton").addEventListener("click", async () => {
  const timeInput = document.getElementById("time");
  const topic = document.getElementById("topic").value.trim();
  const faculty = document.getElementById("faculty").value.trim();
  const duration = parseInt(document.getElementById("duration").value.trim());

  if (!timeInput.value.trim() || !topic || !faculty || isNaN(duration)) {
    alert("Please fill all fields.");
    return;
  }

  const startRaw = formatRawTime(timeInput.value.trim());
  const startTime = formatTimeToAMPM(startRaw);
  const endRaw = addMinutes(startRaw, duration);
  const endTime = formatTimeToAMPM(endRaw);

  const entry = { day: currentDay, startTime, endTime, topic, faculty, duration };

  if (editingIndex !== -1) {
    const originalEntry = scheduleData[currentDay][editingIndex];
    try {
      const res = await fetch(`http://localhost:5000/api/schedule/${originalEntry._id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(entry)
      });
      const updated = await res.json();
      scheduleData[currentDay][editingIndex] = updated;
      updateFollowingTimes(editingIndex);
    } catch (err) {
      console.error("Update failed:", err);
    }
    editingIndex = -1;
  } else {
    try {
      const res = await fetch("http://localhost:5000/api/schedule", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(entry)
      });
      const savedEntry = await res.json();
      scheduleData[currentDay].push(savedEntry);
    } catch (err) {
      console.error("Add failed:", err);
    }
  }

  renderTable();
  autoFillNextStartTime(endRaw);
  clearInputs(true);
});

function renderTable() {
  const tableBody = document.getElementById("scheduleTable");
  tableBody.innerHTML = "";

  scheduleData[currentDay].forEach((entry, index) => {
    const row = document.createElement("tr");

    row.innerHTML = `
      <td>${entry.startTime} - ${entry.endTime}</td>
      <td>${entry.topic}</td>
      <td>${entry.faculty}</td>
      <td>${entry.duration}</td>
      <td>
        <button class="action-btn edit" onclick="editEntry(${index})" style="background-color: #a855f7; color: white;">✏️ Edit</button>
        <button class="action-btn delete" onclick="deleteEntry(${index})" style="background-color: #7c3aed; color: white;">🗑️ Delete</button>
      </td>
    `;

    tableBody.appendChild(row);
  });
}

function editEntry(index) {
  const entry = scheduleData[currentDay][index];
  document.getElementById("time").value = getRawTime(entry.startTime);
  document.getElementById("topic").value = entry.topic;
  document.getElementById("faculty").value = entry.faculty;
  document.getElementById("duration").value = entry.duration;
  editingIndex = index;
}

async function deleteEntry(index) {
  if (confirm("Are you sure you want to delete this entry?")) {
    const entry = scheduleData[currentDay][index];
    try {
      await fetch(`http://localhost:5000/api/schedule/${entry._id}`, {
        method: "DELETE"
      });
      scheduleData[currentDay].splice(index, 1);
      renderTable();
      autoFillFromLast();
    } catch (err) {
      console.error("Delete failed:", err);
    }
  }
}

function formatRawTime(input) {
  if (!input.includes(":")) {
    let hour = parseInt(input);
    if (isNaN(hour)) return "00:00";
    return `${hour.toString().padStart(2, '0')}:00`;
  }
  return input;
}

function formatTimeToAMPM(hhmm) {
  const [hourStr, minuteStr] = hhmm.split(":");
  let hour = parseInt(hourStr);
  const minute = parseInt(minuteStr);
  const suffix = hour >= 12 ? "PM" : "AM";
  hour = hour % 12 || 12;
  return `${hour}:${minute.toString().padStart(2, '0')} ${suffix}`;
}

function addMinutes(hhmm, minsToAdd) {
  const [hourStr, minStr] = hhmm.split(":");
  let hour = parseInt(hourStr);
  let minute = parseInt(minStr);

  let total = hour * 60 + minute + minsToAdd;
  let newHour = Math.floor(total / 60) % 24;
  let newMin = total % 60;

  return `${newHour.toString().padStart(2, '0')}:${newMin.toString().padStart(2, '0')}`;
}

function getRawTime(amPmTime) {
  const [time, modifier] = amPmTime.split(" ");
  let [hour, minute] = time.split(":").map(Number);

  if (modifier === "PM" && hour !== 12) hour += 12;
  if (modifier === "AM" && hour === 12) hour = 0;

  return `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
}

function updateFollowingTimes(startIndex) {
  let prevEndRaw = getRawTime(scheduleData[currentDay][startIndex].endTime);
  for (let i = startIndex + 1; i < scheduleData[currentDay].length; i++) {
    const entry = scheduleData[currentDay][i];
    const newStartRaw = prevEndRaw;
    const newEndRaw = addMinutes(newStartRaw, entry.duration);

    entry.startTime = formatTimeToAMPM(newStartRaw);
    entry.endTime = formatTimeToAMPM(newEndRaw);
    prevEndRaw = newEndRaw;
  }
}

function autoFillNextStartTime(endRaw) {
  const nextStart = addMinutes(endRaw, 1);
  document.getElementById("time").value = nextStart;
}

function autoFillFromLast() {
  const lastEntry = scheduleData[currentDay].at(-1);
  if (lastEntry) {
    const lastEndRaw = getRawTime(lastEntry.endTime);
    autoFillNextStartTime(lastEndRaw);
  } else {
    document.getElementById("time").value = '';
  }
}

function clearInputs(keepTime = false) {
  if (!keepTime) document.getElementById("time").value = '';
  document.getElementById("topic").value = '';
  document.getElementById("faculty").value = '';
  document.getElementById("duration").value = '';
}

async function downloadPDF() {
  const pdfBody = document.getElementById("pdf-body");
  pdfBody.innerHTML = "";

  scheduleData[currentDay].forEach(entry => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${entry.startTime} - ${entry.endTime}</td>
      <td>${entry.topic}</td>
      <td>${entry.faculty}</td>
      <td>${entry.duration}</td>
    `;
    pdfBody.appendChild(row);
  });

  const pdfTable = document.getElementById("pdf-table");
  pdfTable.style.display = "table";

  const canvas = await html2canvas(pdfTable);
  const imgData = canvas.toDataURL("image/png");

  const { jsPDF } = window.jspdf;
  const pdf = new jsPDF("p", "mm", "a4");

  const pageWidth = pdf.internal.pageSize.getWidth();
  const imgProps = pdf.getImageProperties(imgData);
  const imgHeight = (imgProps.height * pageWidth) / imgProps.width;

  pdf.addImage(imgData, 'PNG', 0, 10, pageWidth, imgHeight);
  pdf.save("conference_schedule.pdf");

  pdfTable.style.display = "none";
}
